#!/bin/bash

# 交易机器人停止脚本

if [ -f "bot.pid" ]; then
    PID=$(cat bot.pid)
    echo "停止进程 $PID..."
    kill $PID 2>/dev/null
    rm -f bot.pid
    echo "程序已停止"
else
    echo "没有找到PID文件，尝试强制停止..."
    pkill -f "enhanced_monitor.py"
    echo "程序已停止"
fi
