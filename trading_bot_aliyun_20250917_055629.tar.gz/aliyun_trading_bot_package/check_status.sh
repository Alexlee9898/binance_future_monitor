#!/bin/bash

# 状态检查脚本

echo "=== 交易机器人状态检查 ==="

# 检查进程
if pgrep -f "enhanced_monitor.py" > /dev/null; then
    echo "✅ 程序正在运行"
    echo "PID: $(pgrep -f "enhanced_monitor.py")"
else
    echo "❌ 程序未运行"
fi

# 检查日志文件
if [ -f "logs/enhanced_binance_monitor.log" ]; then
    LOG_SIZE=$(du -h logs/enhanced_binance_monitor.log | cut -f1)
    echo "📊 主日志文件大小: $LOG_SIZE"
    echo "📝 最近5条日志:"
    tail -5 logs/enhanced_binance_monitor.log | grep -o '"message": "[^"]*"' | tail -5
fi

# 检查数据文件
if [ -f "binance_monitor.db" ]; then
    DB_SIZE=$(du -h binance_monitor.db | cut -f1)
    echo "💾 数据库大小: $DB_SIZE"
fi

# 检查配置
echo "🔧 配置状态:"
if [ -f "telegram_config.py" ]; then
    echo "   Telegram配置: 已设置"
else
    echo "   Telegram配置: 未设置"
fi

echo "========================"
