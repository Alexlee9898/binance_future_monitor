#!/bin/bash

# 系统服务安装脚本
# 使用方法: sudo ./install_service.sh

SERVICE_NAME="trading-bot"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
USER=$(whoami)

echo "安装系统服务: $SERVICE_NAME"

# 创建服务文件
sudo tee /etc/systemd/system/$SERVICE_NAME.service > /dev/null << EOL
[Unit]
Description=Trading Bot Monitor
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_DIR
ExecStart=$PROJECT_DIR/start_bot.sh production
ExecStop=$PROJECT_DIR/stop_bot.sh
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOL

# 重新加载systemd
sudo systemctl daemon-reload

# 启用服务
sudo systemctl enable $SERVICE_NAME

echo "服务安装完成！"
echo "使用方法:"
echo "  启动服务: sudo systemctl start $SERVICE_NAME"
echo "  停止服务: sudo systemctl stop $SERVICE_NAME"
echo "  查看状态: sudo systemctl status $SERVICE_NAME"
echo "  查看日志: sudo journalctl -u $SERVICE_NAME -f"
