#!/bin/bash

# 交易机器人启动脚本
# 使用方法: ./start_bot.sh [环境]

ENV=${1:-production}
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="$PROJECT_DIR/logs/bot_start.log"

echo "$(date): 开始启动交易机器人..." >> $LOG_FILE

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "创建虚拟环境..."
    python3 -m venv venv
fi

# 激活虚拟环境
source venv/bin/activate

# 检查依赖
echo "检查依赖包..."
pip install -r requirements.txt

# 设置环境变量
export TELEGRAM_BOT_TOKEN=$(cat telegram_config.py | grep "TELEGRAM_BOT_TOKEN" | cut -d'"' -f2)
export TELEGRAM_CHAT_ID=$(cat telegram_config.py | grep "TELEGRAM_CHAT_ID" | cut -d'"' -f2)

# 启动程序
echo "启动程序..."
if [ "$ENV" = "test" ]; then
    python3 enhanced_monitor.py
else
    nohup python3 enhanced_monitor.py > logs/output.log 2>&1 &
echo $! > bot.pid
    echo "程序已在后台启动，PID: $(cat bot.pid)"
fi

echo "$(date): 启动完成" >> $LOG_FILE
